package com.example.proj

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.example.proj.LessonData
import androidx.appcompat.app.AppCompatActivity

class LessonDetailsActivity : AppCompatActivity() {

    private lateinit var lessonTitle: TextView
    private lateinit var lessonNumberView: TextView
    private lateinit var lessonLength: TextView
    private lateinit var lessonDescription: TextView
    private lateinit var watchLessonButton: Button
    private lateinit var notesEditText: EditText
    private lateinit var saveNotesButton: Button
    private lateinit var markCompletedButton: Button

//    private var lesson: Lesson? = null
    private var position = -1
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.lessondetails)

        if(intent != null){
            this.position = intent.getIntExtra("EXTRA_POSITION", -1)
            Log.d("MY-APP", this.position.toString())
            val dataStore = LessonData.getInstance()
            val lesson = dataStore.lessons[this.position]
            lessonTitle = findViewById(R.id.title_text_view)
            lessonNumberView = findViewById(R.id.number_text_view)
            lessonLength = findViewById(R.id.length_text_view)
            lessonDescription = findViewById(R.id.description_text_view)

            lessonTitle.text = lesson.name
            lessonNumberView.text = lesson.number.toString()
            lessonLength.text = lesson.length
            lessonDescription.text = lesson.description

            watchLessonButton = findViewById(R.id.video_web_view)
            notesEditText = findViewById(R.id.notes_edit_text)
            markCompletedButton = findViewById(R.id.mark_completed_button)
            saveNotesButton = findViewById(R.id.save_notes_button)

            // Load notes from SharedPreferences
            sharedPreferences = getSharedPreferences("lesson_${lesson.number}", MODE_PRIVATE)
            val savedNotes = sharedPreferences.getString("notes", "")
            notesEditText.setText(savedNotes)

            watchLessonButton.setOnClickListener {
                // Launch the video in a WebView or an external app
                val intent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://youtu.be/${lesson.videoId}")
                )
                startActivity(intent)
            }

            saveNotesButton.setOnClickListener {
                // Save notes to SharedPreferences
                val notes = notesEditText.text.toString()
                sharedPreferences.edit().putString("notes", notes).apply()
                Toast.makeText(this, "Notes saved!", Toast.LENGTH_SHORT).show()
            }

            markCompletedButton.setOnClickListener {
                // Mark lesson as completed in SharedPreferences
                sharedPreferences.edit().putBoolean("completed", true).apply()
                Toast.makeText(this, "Lesson marked as completed!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}