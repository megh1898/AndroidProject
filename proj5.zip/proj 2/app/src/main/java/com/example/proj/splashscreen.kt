package com.example.proj

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler



@SuppressLint("CustomSplashScreen")
class splashscreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val splashTimeOUt:Long = 3000 // 1 sec
        setContentView(R.layout.activity_splashscreen)




            Handler().postDelayed({
                // This method will be executed once the timer is over
                // Start your app main activity

                startActivity(Intent(this,MainActivity::class.java))

                // close this activity
                finish()
            }, splashTimeOUt)
    }
}