package com.example.proj

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ListView
import android.widget.Switch
import androidx.appcompat.app.AppCompatActivity

class LessonsListActivity : AppCompatActivity() {

    private lateinit var lessonListView: ListView
    private lateinit var switch: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lessons)

        lessonListView = findViewById(R.id.lesson_list)
        switch = findViewById(R.id.toggle_button)

        lessonListView.adapter = LessonListAdapter(this, LessonData.getInstance().lessons, switch.isChecked)

        lessonListView.setOnItemClickListener { _, _, position, _ ->
            if (!switch.isChecked || position == 0 || LessonData.getInstance().lessons[position - 1].isCompleted) {
                val intent = Intent(this, LessonDetailsActivity::class.java)
                intent.putExtra("EXTRA_POSITION", position)
                Log.d("My-App1", position.toString())
                startActivity(intent)
            }
        }

        switch.setOnCheckedChangeListener { _, isChecked ->
            lessonListView.adapter = LessonListAdapter(this, LessonData.getInstance().lessons, isChecked)
        }

        // Set the forceSequentialProgression flag to true
        (lessonListView.adapter as LessonListAdapter).setForceSequentialProgression(false)
    }
}