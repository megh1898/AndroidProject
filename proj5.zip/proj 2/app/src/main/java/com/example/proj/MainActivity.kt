package com.example.proj

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.content.Intent
import android.util.Log

class MainActivity : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        sharedPreferences = getSharedPreferences("my_app", Context.MODE_PRIVATE)
//        if (!sharedPreferences.contains("name") ||intent.getBooleanExtra("reset",false)){

            var nameEditText:EditText = findViewById(R.id.etNameText)
            var continueButton:Button = findViewById(R.id.btnContinueButton)
            continueButton.setOnClickListener {
                val name = nameEditText.text.toString().trim()
                sharedPreferences.edit().putString("name", name).apply()
                val intent = Intent(this, WelcomeBackScreen::class.java)
                startActivity(intent)
                finish()
//            }

        }
    }
}