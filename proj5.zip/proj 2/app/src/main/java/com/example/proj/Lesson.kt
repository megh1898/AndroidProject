package com.example.proj

data class Lesson(
    var number: Int,
    var name: String,
    var length: String,
    var videoId: String,
    var description: String,
    var isCompleted: Boolean = false,
) {
    var check: Int = if (isCompleted) 1 else 0
}