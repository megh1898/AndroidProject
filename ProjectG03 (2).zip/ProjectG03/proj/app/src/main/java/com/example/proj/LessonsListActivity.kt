package com.example.proj

import android.content.Intent
import android.os.Bundle
import android.widget.ListView
import android.widget.Switch
import androidx.appcompat.app.AppCompatActivity

class LessonsListActivity : AppCompatActivity() {

    private lateinit var lessonListView: ListView
    private lateinit var switch: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lessons)

        lessonListView = findViewById(R.id.lesson_list)
        switch = findViewById(R.id.toggle_button)

        lessonListView.adapter = LessonListAdapter(this, LessonData.lessons, switch.isChecked)

        lessonListView.setOnItemClickListener { _, _, position, _ ->
            val lesson = LessonData.lessons[position]
            if (!switch.isChecked || position == 0 || LessonData.lessons[position - 1].isCompleted) {
                val intent = Intent(this, LessonDetailsActivity::class.java)
                intent.putExtra("lessonNumber", lesson.number)
                startActivity(intent)
            }
        }

        switch.setOnCheckedChangeListener { _, isChecked ->
            lessonListView.adapter = LessonListAdapter(this, LessonData.lessons, isChecked)
        }

        // Set the forceSequentialProgression flag to true
        (lessonListView.adapter as LessonListAdapter).setForceSequentialProgression(false)
    }
}