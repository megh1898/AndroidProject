package com.example.proj

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.content.Intent

class MainActivity : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sharedPreferences = getSharedPreferences("my_app", Context.MODE_PRIVATE)

        val nameInput: EditText = findViewById(R.id.etNameText)
        val continueButton: Button = findViewById(R.id.btnContinueButton)

        continueButton.setOnClickListener {
            val name = nameInput.text.toString().trim()
            if (name.isNotEmpty()) {
                sharedPreferences.edit().putString("name", name).apply()
                val intent = Intent(this, LessonsListActivity::class.java)
                startActivity(intent)
                finish()
            }
        }

        // Check if the user selected Reset on the Welcome Back screen
        val isReset = intent.getBooleanExtra("reset", false)
        if (isReset) {
            sharedPreferences.edit().remove("name").remove("completed_lessons").apply()
        }
        // Check if this is the first time the app is run
        val isFirstRun = sharedPreferences.getBoolean("first_run", true)
        if (!isReset && !isFirstRun) {
            val intent = Intent(this, WelcomeBackScreen::class.java)
            startActivity(intent)
            finish()
        } else {
            sharedPreferences.edit().putBoolean("first_run", false).apply()
        }
    }
    }