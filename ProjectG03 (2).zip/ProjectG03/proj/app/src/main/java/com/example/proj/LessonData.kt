package com.example.proj

import android.content.Context

class LessonData {

    companion object {
    val lessons: MutableList<Lesson> = mutableListOf(
        Lesson(1, "Introduction","20:00 min", "https://youtu.be/hu-q2zYwEYs","Welcome to your very first HTML & CSS tutorial. Throughout this crash course series I'll take you from total beginner to create great-looking sites with HTML & CSS. In this video, we'll cover what HTML & CSS are, as well as setting up our dev environment."),
        Lesson(2, "Getting Started with HTML", "19:51", "https://youtu.be/mbeT8mpmtHA","In this HTML tutorial I'll show you the basics of HTML syntaxt and how to construct HTML tags & documents."),
        Lesson(3, "Intermediate Concepts", "31:55", "https://youtu.be/YwbIeMlxZAU","In this HTML tutorial I'll explain how to create forms in HTML, (using some newer HTML 5 input fields too). We'll look at email fields, text fields, password fields and more."),
        Lesson(4, "Getting Started with CSS", "42:37", "https://youtu.be/D3iEE29ZXRM","In this CSS tutorial for beginners we'll have a look at the basic syntax of CSS and how we can use it to make our web pages look better."),
        Lesson(5, "Advance Concepts", "14:14", "https://youtu.be/kGW8Al_cga4","In this HTML & CSS tutorial for beginners we'll take a look at some of the newer HTML semantic tags, like section, article, header, nav and aside."),
        Lesson(6, "Working with a Project", "1:25:19", "https://youtu.be/FazgJVnrVuI","Learn how to build a website using HTML, CSS, and Javascript in this beginner project tutorial. The site will be fully responsive and you can navigate to other pages and add your own custom design.")
    )

        @Volatile
        private lateinit var instance: LessonData


        fun getLessonByNumber(lessonNumber: Int): Lesson? {
            return lessons.find { it.number == lessonNumber }
        }

        fun getInstance(context: Context): LessonData {
            synchronized(this) {
                if (!Companion::instance.isInitialized) {
                    instance = LessonData()
                }
                return instance
            }
        }
    }
}