package com.example.proj

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class LessonListAdapter(
    private val context: Context,
    private var lessonList: MutableList<Lesson>,
    private var forceSequentialProgression: Boolean = false,
    private var toggleButton: Boolean = false
) : BaseAdapter() {

    private val inflater: LayoutInflater = LayoutInflater.from(context)

    override fun getCount(): Int {
        return lessonList.size
    }

    override fun getItem(position: Int): Any {
        return lessonList[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var view = convertView
        val holder: ViewHolder

        if (view == null) {
            view = inflater.inflate(R.layout.lesson_list_view, parent, false)
            holder = ViewHolder()

            holder.lessonNumber = view.findViewById(R.id.lesson_number)
            holder.lessonName = view.findViewById(R.id.lesson_name)
            holder.lessonLength = view.findViewById(R.id.lesson_length)
            holder.lessonCheck = view.findViewById(R.id.lesson_check)

            view.tag = holder
        } else {
            holder = view.tag as ViewHolder
        }

        val lesson = lessonList[position]

        holder.lessonNumber?.text = lesson.number.toString()
        holder.lessonName?.text = lesson.name
        holder.lessonLength?.text = context.getString(R.string.lesson_length, lesson.length)

        val prefs = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        if (prefs.getBoolean("lesson_" + lesson.number, false)) {
            holder.lessonCheck?.setImageResource(R.drawable.check)
        } else {
            holder.lessonCheck?.setImageResource(0)
        }

        if (forceSequentialProgression && position > 0) {
            val prevLesson = lessonList[position - 1]
            view?.isEnabled = prevLesson.check == 1

            // show check mark even if forceSequentialProgression is enabled
            holder.lessonCheck?.visibility = if (prevLesson.check == 1) View.VISIBLE else View.GONE
        } else {
            view?.isEnabled = true

            // show/hide check mark based on toggleButton flag
            holder.lessonCheck?.visibility =
                if (!toggleButton || lesson.check == 1) View.VISIBLE else View.GONE
        }

        if (forceSequentialProgression && position > 0) {
            val prevLesson = lessonList[position - 1]
            if (prevLesson.check != 1) {
                view?.setOnClickListener {
                    Toast.makeText(
                        context,
                        "Please complete previous lessons first",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } else {
                view?.setOnClickListener {
                    val intent = Intent(context, LessonDetailsActivity::class.java)
                    intent.putExtra("lesson_number", lesson.number)
                    context.startActivity(intent)
                }
            }
        } else {
            view?.setOnClickListener {
                val intent = Intent(context, LessonDetailsActivity::class.java)
                intent.putExtra("lesson_number", lesson.number)
                context.startActivity(intent)
            }
        }

        return view ?: View(context)
    }


    fun setForceSequentialProgression(b: Boolean) {
        forceSequentialProgression = b
        notifyDataSetChanged()
    }


    internal class ViewHolder {
        var lessonNumber: TextView? = null
        var lessonName: TextView? = null
        var lessonLength: TextView? = null
        var lessonCheck: ImageView? = null
    }
}