package com.example.project_g03.activities

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.example.project_g03.R

class LessonListAdapter(context: Context, pets: List<Lesson>) :
    ArrayAdapter<Lesson>(context, 0, pets) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context)
            .inflate(R.layout.lesson_list_view, parent, false)

        val lessonName = view.findViewById<TextView>(R.id.lesson_name)
        val numberImg = view.findViewById<ImageView>(R.id.img_check)
        val checkImg = view.findViewById<ImageView>(R.id.img_check)
        val lessonLength = view.findViewById<TextView>(R.id.lesson_length)
        val lesson = getItem(position)
        lesson?.let {
            lessonName.text = it.name
            numberImg.setImageResource(it.number)
            checkImg.setImageResource(it.check)
            lessonLength.text = it.length
        }

        return view
    }
}