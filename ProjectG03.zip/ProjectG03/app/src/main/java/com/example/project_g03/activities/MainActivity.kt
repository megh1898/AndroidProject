package com.example.project_g03.activities

import android.content.ContentValues.TAG
import android.os.Bundle
import android.util.Log
import android.widget.ListView
import android.widget.Toast
import android.widget.ToggleButton
import androidx.appcompat.app.AppCompatActivity
import com.example.project_g03.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.d(TAG, "MainActivity - onCreate() executing")

        val lessonList:MutableList<Lesson>
                = LessonData.getInstance().lessonList

        // sending the lessons to the adapter
        val lessonListAdapter = LessonListAdapter(this, lessonList)

        // setup list view with the adapter
        val lesson = findViewById<ListView>(R.id.lesson_list)
        lesson.adapter = lessonListAdapter

        // set up listview click handler
        lesson.setOnItemClickListener { adapterView, view, i, l ->
            Log.d(TAG, "Person clicked on class ${i}")
        }


    }
}