package com.example.project_g03.activities

    data class Lesson(
        var number: Int,
        var name: String,
        var length: String,
        var check: Int
    ){}
