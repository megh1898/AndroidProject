package com.example.project_g03.activities

import com.example.project_g03.R
import com.google.android.material.animation.ArgbEvaluatorCompat

class LessonData {
    var lessonList:MutableList<Lesson> = mutableListOf(
            Lesson(R.drawable.one, "Lesson 1", "5:32", R.drawable.check),
            Lesson(2, "Lesson 2", "7:19", R.drawable.check),
            Lesson(3, "Lesson 3", "10:45", R.drawable.check),
            Lesson(4, "Lesson 4", "6:57", R.drawable.check),
            Lesson(5, "Lesson 5", "9:23", R.drawable.check),
            Lesson(6, "Lesson 6", "8:11", R.drawable.check)
        )
    companion object {
        @Volatile
        private lateinit var instance: LessonData

        fun getInstance(): LessonData {
            synchronized(this) {
                if (!Companion::instance.isInitialized) {
                    instance = LessonData()
                }
                return instance
            }
        }
    }
}