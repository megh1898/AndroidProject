package com.example.proj

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.SharedPreferences
import android.widget.TextView
import android.content.Context
import android.widget.Button
import android.content.Intent


class WelcomeBackScreen : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome_back_screen)
        sharedPreferences = getSharedPreferences("my_app", Context.MODE_PRIVATE)
        var nameText: TextView = findViewById(R.id.tvNameText)
        val name = sharedPreferences.getString("name","")
        nameText.text = "welcome Back,$name!"


        var progressText:TextView = findViewById(R.id.ProgressText)
        val progress = sharedPreferences.getString("progress","")
        progressText.text = "your progress: $progress"


        var proceedButton:Button = findViewById(R.id.btnProgressButton)
        proceedButton.setOnClickListener {
            val intent = Intent(this, LessonsListActivity::class.java)
            startActivity(intent)
            finish()
        }

        var resetButton:Button=findViewById(R.id.btnResetButton)
        resetButton.setOnClickListener {
            sharedPreferences.edit().remove("name").remove("progress").apply()

            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("reset", true)
            startActivity(intent)
            finish()
        }









    }
}